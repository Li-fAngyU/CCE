mkdir Beauty
mkdir LastFM
mkdir Sports_and_Outdoors
mkdir Toys_and_Games
mkdir Yelp